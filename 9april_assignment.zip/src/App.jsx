import { useState, useMemo, Suspense, lazy, useCallback } from 'react';
import Navbar from './components/Navbar';
import HomeScreen from './components/HomeScreen';
import ProductDetails from './components/ProductDetails';

const LoginPage = lazy(() => import('./components/LoginPage'));
const ContactUsPage = lazy(() => import('./components/ContactUsPage'));

function App() {
  const [page, setPage] = useState('home');
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  const handleProductClick = useCallback((product) => setPage({ name: 'product', data: product }), []);
  const handlePageChange = useCallback((newPage) => setPage(newPage), []);

  const renderPage = useMemo(() => {
    if (typeof page === 'object' && page.name === 'product') {
      return <ProductDetails product={page.data} onProductClick={handleProductClick} setPage={handlePageChange} />;
    }
    switch (page) {
      case 'home':
        return <HomeScreen onProductClick={handleProductClick} setPage={handlePageChange} />;
      case 'login':
        return (
          <Suspense
            fallback={
              <div className="min-h-screen flex items-center justify-center bg-gray-100">
                <div className="flex flex-col items-center">
                  <div className="w-12 h-12 border-4 border-t-4 border-gray-200 border-t-blue-600 rounded-full animate-spin"></div>
                  <p className="mt-4 text-gray-600">Loading...</p>
                </div>
              </div>
            }
          >
            <LoginPage setPage={handlePageChange} setIsLoggedIn={setIsLoggedIn} />
          </Suspense>
        );
      case 'contact':
        return (
          <Suspense
            fallback={
              <div className="min-h-screen flex items-center justify-center bg-gray-100">
                <div className="flex flex-col items-center">
                  <div className="w-12 h-12 border-4 border-t-4 border-gray-200 border-t-blue-600 rounded-full animate-spin"></div>
                  <p className="mt-4 text-gray-600">Loading...</p>
                </div>
              </div>
            }
          >
            <ContactUsPage setPage={handlePageChange} />
          </Suspense>
        );
      default:
        return <HomeScreen onProductClick={handleProductClick} setPage={handlePageChange} />;
    }
  }, [page, handleProductClick, handlePageChange]);

  return (
    <div>
      <Navbar setPage={handlePageChange} isLoggedIn={isLoggedIn} setIsLoggedIn={setIsLoggedIn} />
      {renderPage}
    </div>
  );
}

export default App;