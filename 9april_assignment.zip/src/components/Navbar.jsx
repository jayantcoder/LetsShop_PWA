import React from 'react';

const Navbar = ({ setPage, isLoggedIn, setIsLoggedIn }) => (
  <nav className="navbar text-white p-4 flex justify-between items-center shadow-lg fixed top-0 w-full z-10">
    <div
      className="text-3xl font-extrabold tracking-tight cursor-pointer hover:text-yellow-300 transition-colors duration-200"
      onClick={() => setPage('home')}
    >
      ShopNow
    </div>
    <div className="flex items-center space-x-6">
      <a href="#" onClick={() => setPage('home')} className="hover:text-yellow-300 transition-colors duration-200 font-medium">Home</a>
      {isLoggedIn ? (
        <a href="#" onClick={() => { setIsLoggedIn(false); setPage('home'); }} className="hover:text-yellow-300 transition-colors duration-200 font-medium">Logout</a>
      ) : (
        <a href="#" onClick={() => setPage('login')} className="hover:text-yellow-300 transition-colors duration-200 font-medium">Login</a>
      )}
      <a href="#" onClick={() => setPage('contact')} className="hover:text-yellow-300 transition-colors duration-200 font-medium">Contact</a>
    </div>
  </nav>
);

export default React.memo(Navbar);