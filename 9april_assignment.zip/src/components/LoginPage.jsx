import React, { useState, useCallback } from 'react';

const LoginPage = ({ setPage, setIsLoggedIn }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [emailError, setEmailError] = useState('');

  const validateEmail = (email) => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  };

  const handleLogin = useCallback(() => {
    if (!email || !password) {
      setEmailError('Email and password are required');
      return;
    }
    if (!validateEmail(email)) {
      setEmailError('Please enter a valid email');
      return;
    }
    setEmailError('');
    console.log('Login:', { email, password });
    setIsLoggedIn(true); 
    setPage('home'); 
  }, [email, password, setPage, setIsLoggedIn]);

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-100">
      <div className="bg-white p-8 rounded-lg shadow-lg w-full max-w-md transform transition-all hover:shadow-xl">
        <h2 className="text-3xl font-bold mb-6 text-center text-gray-800">Login</h2>
        <input
          type="email"
          value={email}
          onChange={(e) => {
            setEmail(e.target.value);
            setEmailError('');
          }}
          placeholder="Email"
          className={`w-full p-3 mb-4 border rounded-lg focus:outline-none focus:ring-2 ${emailError ? 'border-red-500' : 'focus:ring-blue-300'}`}
          required
        />
        {emailError && <p className="text-red-500 text-sm mb-4">{emailError}</p>}
        <input
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          placeholder="Password"
          className="w-full p-3 mb-6 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-300"
          required
        />
        <button
          onClick={handleLogin}
          className="w-full bg-blue-600 text-white p-3 rounded-lg hover:bg-blue-700 transition-colors"
        >
          Login
        </button>
        <a href="#" onClick={() => setPage('home')} className="block text-center mt-4 text-blue-600 hover:underline">
          Back to Home
        </a>
      </div>
    </div>
  );
};

export default LoginPage;